package io.virtualapp.abs;

/**
 * @author Lody
 */
public interface BasePresenter {
	void start();
}
