package io.virtualapp.abs;

/**
 * @author Lody
 */

public class Value<T> {
    public T val;
}
