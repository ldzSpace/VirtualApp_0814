package io.virtualapp.vs;

import io.virtualapp.abs.ui.VActivity;

/**
 * @author Lody
 *
 *
 *
 */
public class VSManagerActivity extends VActivity {
}
