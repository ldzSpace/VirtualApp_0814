package mirror.android.rms.resource;


import mirror.RefClass;
import mirror.RefObject;

public class ReceiverResourceLP {
    public static Class<?> TYPE = RefClass.load(ReceiverResourceLP.class, "android.rms.resource.ReceiverResource");
    public static RefObject<Object> mResourceConfig;
}