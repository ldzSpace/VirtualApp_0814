package mirror.android.content;

import android.content.ContentResolver;

import mirror.RefClass;
import mirror.RefObject;

public class ContentResolverJBMR2 {
    public static Class Class = RefClass.load(ContentResolverJBMR2.class, ContentResolver.class);;
    public static RefObject<String> mPackageName;
}
